function cn = getClusterNameFlag(cluster, job)

% Copyright 2023 The MathWorks, Inc.

jobData = cluster.getJobClusterData(job);
if isfield(jobData,'ClusterName')
    cn = ['-M ' jobData.ClusterName];
else
    % Just in case ClusterName wasn't stored
    cn = '';
end
